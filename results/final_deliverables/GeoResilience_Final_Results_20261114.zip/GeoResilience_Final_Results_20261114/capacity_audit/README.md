# Road-capacity audit

Both original study networks were audited and their intact traffic reassigned using the unchanged OD demand, speed table, BPR parameters and convergence target. No composite or flood outputs were overwritten.

| Area | Directed arcs | Lane-based | Width-based | Defaults | Default % | Directional tags | Changed capacities |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| gachibowli | 1305 | 127 | 2 | 1176 | 90.115 | 0 | 0 |
| old-hyderabad | 8435 | 19 | 0 | 8416 | 99.775 | 0 | 0 |

Lane/width tags constrain geometry; the configured PCU/hour/lane remains an assumption. Missing archival tags cannot be recovered by changing a parser. No new OSM download was substituted, so geography and road identities remain matched.

Rules: use explicit directional counts only with unambiguous OSMnx way orientation; exclude shared centre lanes from independent through capacity; derive a missing directional count only from consistent total/opposite counts; otherwise label equal splits, width inference or configured defaults. One-way totals are not halved. Shared narrow-road conflicts, reserved lanes, signals and parking are not calibrated.

Per-city traffic_arcs.csv includes original capacity tags, resolved rule, assumptions and invalid-field flags; capacities.csv provides compatible values-only overrides. summary.json records raw and retained tag inventories, exact baseline differences and convergence. manifest.json binds consumed inputs and implementation files by SHA-256.

Reproduce with PYTHONPATH=src and python examples/traffic/audit_capacities.py --output <fresh-directory>.
