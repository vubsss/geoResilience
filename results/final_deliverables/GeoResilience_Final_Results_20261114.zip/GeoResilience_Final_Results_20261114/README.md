# GeoResilience: final Old Hyderabad / Gachibowli results

Population-weighted traffic-and-flood scenario. Original composite weights retained: attack 25%; bridge, detour, Hansen accessibility, travel-time reliability and connectivity reliability 15% each. Facility metrics are separate.

| Normalized component | Gachibowli | Old Hyderabad |
| --- | ---: | ---: |
| Bridge redundancy | 0.746309 | 0.809469 |
| Detour redundancy | 0.163616 | 0.197395 |
| Targeted attack robustness | 0.118961 | 0.062772 |
| Hansen accessibility | 0.709795 | 0.610782 |
| Travel-time reliability | 0.798393 | 0.608982 |
| Mutual-pair connectivity reliability | 0.794434 | 0.644976 |
| **Composite** | **0.511622** | **0.446434** |

## Start here

- `final_scores.csv`: six normalized headline components and composite.
- `comparison/components.png` and `comparison/composite.png`: ready-to-use charts; SVG versions included.
- `cities/<city>/analysis/report.txt`: readable individual metrics, assumptions and facility results.
- `cities/<city>/analysis/summary.json`: complete unweighted/population-weighted results; `headline` selects the population view.
- `cities/<city>/analysis/composite.csv`: component values, original weights and contributions.
- `cities/<city>/analysis/network.gpkg`: QGIS layers `nodes`, `edges`, `traffic_arcs`, `facilities`.
- `cities/<city>/analysis/figures/`: all exported metric and service figures.
- `cities/<city>/analysis/traffic_arcs.csv`, `traffic_od.csv`, `traffic_failure_states.csv`, `attack_curve.csv`: detailed numerical outputs.
- `cities/<city>/flood/`: road probabilities, enriched road network, coverage and manifest; generated terrain intermediates retained.
- `cities/<city>/prepared/`, `study_config.json`, `workflow_complete.json`: standard workflow handoff and completion records.
- `shared_flood_model/`: common maximum-depth raster and original hydraulic manifest/coverage, preserving simulation assumptions.
- `capacity_audit/`: completed tag coverage and matched intact traffic replay for both areas.
- `configuration/`: original study/scenario configurations and facility-coverage exclusions.
- `verification/`: original acceptance receipt, current regression log and package checksums.

## What was verified

Both final studies already existed and completed successfully. Their original output hashes and consumed-input hashes were verified. Each extracted mid-evaluation raw road network matches the network used in its final run. The later capacity audit produced exactly unchanged capacities, free-flow times, volumes and congested times. All 64 sampled assignments converged per area. The current capacity regression suite passed 437 tests, with 6 skipped.

No alternative composite weights or traffic-only 99/100 index are used in this package. The historical `original_run_acceptance.json` retains its historical test counts; the later current-suite result is in `capacity_regression.log`.

## Interpretation and scope

These are modeled scenario estimates, not observed present-day traffic or validated actual flood closures. Demand and most capacities are assumptions. The flood model uses reported daily rainfall, 120 m terrain, assumed runoff/roughness and uncalibrated fragility. Original hydraulic limitations are in shared_flood_model/closure_manifest.json. Gachibowli facility coverage is incomplete and institution capacities are assumed units.

The composite uses normalized components. Raw metric-family fields retain their definitions: detour is a median finite ratio and attack is raw AUC. Do not plot these raw fields as if they were the normalized components.

The production adaptive attack protocol differs from the old mid-evaluation directed/batched protocol. These final scores are not a controlled traffic-only comparison against the old presentation scores. Local criticality is screened; probability-based failure reliability reassigns traffic, while targeted attack/local removal use intact fixed congested costs.

## Reproduction

Manifests and configurations preserve original paths and hashes. They are audit records, not relocated runnable configurations. Rerunning requires the project repository, original road/population/OD/facility inputs and appropriate path updates. The ZIP itself is sufficient to inspect the results in QGIS, read the tables and view figures.
