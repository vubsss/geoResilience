"""Compatibility entry point for the shared local-population runner."""

from pathlib import Path
import runpy
import sys


runner = Path(__file__).resolve().parents[1] / "run_population.py"
sys.argv = [str(runner), "gachibowli", *sys.argv[1:]]
runpy.run_path(str(runner), run_name="__main__")
