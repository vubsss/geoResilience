# Hyderabad critical-node analysis inputs

Prepared 13 November 2026 for GeoResilience. This package contains analysis-ready
inputs for two separate study areas. Capacity is uniformly assumed as requested.
Full node/link closure results have not been computed in this package.

## Contents and input format

```text
hyderabad-critical-node-inputs/
  inputs/
    gachibowli/
      roads.osm
      boundary.geojson
      facilities.csv
    old-hyderabad/
      roads.osm
      boundary.geojson
      facilities.csv
  sources/                 # school/hospital source tables and provenance
  validation.json          # actual loader, snapping and baseline 2SFCA checks
  run_analysis.py
  validate_inputs.py
  SHA256SUMS.txt
```

Each input directory has exactly one supported OSM XML road file. Only highway
ways and their referenced nodes are included, so building footprints cannot become
road edges. Facilities use an explicit CSV path with these exact headers:

```csv
facility_id,service_type,longitude,latitude,capacity,capacity_unit,capacity_source,name,capacity_year,notes
```

Coordinates are WGS84 longitude/latitude in decimal degrees. Facility IDs are
unique strings. Service types are `school` and `hospital`. Every capacity is `1`.
Units are `assumed_school_capacity_units` or `assumed_hospital_capacity_units`.
The source field states the uniform assumption. Capacity years are blank because
these are assumptions rather than annual measurements. They are not measured
student seats or staffed hospital beds.

## Study extents

| Area | West, south, east, north (degrees) | Schools | Hospitals |
| --- | --- | ---: | ---: |
| Gachibowli | 78.325, 17.415, 78.385, 17.455 | 41 | 19 |
| Old Hyderabad, centered near Charminar | 78.445, 17.342, 78.505, 17.382 | 742 | 55 |

These are approximately equal-area test rectangles, not official neighbourhood
boundaries. Road requests extend 0.01 degrees beyond each side. OSM ways returned
in full can extend further. Facility selection uses the inner rectangle.

## Run the analysis

Use the current GeoResilience repository, which supports `--service-mode 2sfca`.
If needed, install it from its repository root:

```sh
python -m pip install -e .
```

Then run the script below with the same Python environment. Substitute the
actual path where you extracted this package. Outputs must be outside the
per-area input directories.

```sh
python /path/to/hyderabad-critical-node-inputs/run_analysis.py --out /path/to/results/hyderabad-uniform
```

For one area:

```sh
python /path/to/hyderabad-critical-node-inputs/run_analysis.py --area old-hyderabad --out /path/to/results/hyderabad-uniform
python /path/to/hyderabad-critical-node-inputs/run_analysis.py --area gachibowli --out /path/to/results/hyderabad-uniform
```

The script uses screened node/link closures, 10-minute school and hospital
catchments, equal category importance, no intersection consolidation, and
validated per-area facility snap limits. Catchments are illustrative scenario
assumptions. Change both with `--catchment-minutes NUMBER`.

Screening evaluates selected candidates, including facility-bearing nodes,
and can miss the globally most critical node. For exhaustive node/link closure
rankings, append `--coverage all`. This can take substantially longer. Use
`--dry-run` to print exact CLI commands without launching the analysis.

The 64 failure samples and 1% static attack horizon are preliminary-run settings.
They do not reduce the accuracy of the deterministic evaluated closure scores.
Use `--samples NUMBER` for a larger reliability simulation. Existing nonempty
results require an explicit `--overwrite`.

## Where to see critical nodes after a run

Each area's output contains `network.gpkg`, `report.txt`, `summary.json`,
`run_manifest.json`, `attack_curve.csv` and figures. Open the GeoPackage's
`nodes` layer in QGIS. Higher `school_access_shortfall`,
`hospital_access_shortfall` and `service_combined_shortfall` indicate more
critical node closures. Check `service_evaluated`: unevaluated nodes have null
closure scores. School and hospital maps are `figures/school_criticality.png`
and `figures/hospital_criticality.png`. JSON rankings are under
`services.criticality.rankings.nodes`.

## Demand, routing and source limits

No population raster was supplied. The service-enabled pipeline therefore uses
one uniform demand unit per retained road node, including buffered roads.
These are not resident-weighted results. The boundary file does not clip the
road graph or uniform fallback demand. To obtain population-weighted results,
add exactly one georeferenced, single-band population-count `.tif` to each input
directory and rerun. Its counts must overlap the supplied boundary.

Static free-flow times are resolved by the project from OSM speed tags and
network road-class means, with provenance in the validation and run manifests.
They do not represent congestion. Facility locations snap to retained road nodes,
not verified entrances. The validation file lists all attachment distances and
any exceeding 500 m. Consolidation is disabled because the 15 m default fails
the existing Gachibowli dead-end preservation check.

Schools are operational UDISE+ records from the pinned India School Coordinates
v1.0 compilation. Gachibowli requires the SERILINGAMPALLY block; Old City requires
HYDERABAD district. Records inside the rectangle with other directory locations
are retained for review in provenance, but excluded from facility inputs.
The coordinates may be older than their September 2026 retrieval timestamps.
Distinct school IDs with shared coordinates remain separate institutions and
are listed in provenance. Higher-secondary/junior-college records are included.

Hospitals are OpenStreetMap features tagged `amenity=hospital` or
`healthcare=hospital`. Polygon features use representative points. Quality flags
preserve clinic-like names, unnamed facilities and unverified imported geocodes.
The lists are not verified inventories. Gachibowli reuses the existing November 7
downloads; Old City roads/hospitals were downloaded November 13. Boundary effects
and missing neighbouring supply/demand are not corrected.

## Sources and verification

Schools: Government of India UDISE+ via
[India School Coordinates v1.0](https://github.com/DavidChristopherNelson/india-school-coordinates/releases/tag/v1.0).
The full 1,730,760-row release was checked against its pinned SHA-256. Local
source tables retain IDs, directory attributes, source URLs and timestamps.

Roads and hospitals: © [OpenStreetMap contributors](https://www.openstreetmap.org/copyright),
ODbL. Public API tile checksums and selection rules are in each provenance file.
Preserve attribution when redistributing derivatives.

`validation.json` records actual successful directory discovery, capacity-aware
CSV loading, drive-network cleaning, every facility attachment, static-time
availability and baseline 2SFCA computation for both categories. These are input
validation checks, not completed closure rankings. Recheck from the installed
project environment with `python /path/to/hyderabad-critical-node-inputs/validate_inputs.py`.

From the extracted package root, check file integrity with:

```sh
sha256sum -c SHA256SUMS.txt
```
