"""Run from an environment with this GeoResilience repository installed."""
import json
import math
from pathlib import Path

import numpy as np

from georesilience.config import ServicesConfig
from georesilience.inputs import directory_config
from georesilience.links import _link_rows
from georesilience.network import load_and_clean
from georesilience.pipeline import _versions
from georesilience.service_inputs import load_facility_records
from georesilience.services import prepare_services
from georesilience.sfca import compute_sfca
from georesilience.time_models import prepare_time_model
from georesilience.time_routing import prepare_static_time

BASE = Path(__file__).resolve().parent


def validate():
    results = {}
    for area in ('gachibowli', 'old-hyderabad'):
        directory = BASE / 'inputs' / area
        config = directory_config(directory, consolidate=False, allow_missing_population=True)
        config.services = ServicesConfig(facilities_csv=directory / 'facilities.csv', mode='sfca',
            snap_max_m=10000,
            school={'catchment_minutes':10, 'capacity_unit':'assumed_school_capacity_units'},
            hospital={'catchment_minutes':10, 'capacity_unit':'assumed_hospital_capacity_units'})
        records = load_facility_records(config.services)
        assert all(f.capacity == 1 for f in records)
        graph, meta, cleaning = load_and_clean(config)
        attached = prepare_services(graph, config.services)
        maximum = max(f.snap_m for f in attached.facilities)
        snap_limit = max(600, math.ceil(maximum / 100) * 100)
        config.services.snap_max_m = snap_limit
        attached = prepare_services(graph, config.services)
        times = prepare_time_model(graph, config.travel_time)
        routing = prepare_static_time(graph, _link_rows(graph), config.travel_time, prepared=times)
        assert routing.reason is None, routing.reason
        baseline = compute_sfca(attached, np.ones(len(graph)), config.services, routing,
            budget_bytes=2**28, demand_basis='uniform_node_demand')
        assert all(c.summary['status'] == 'computed' for c in baseline.categories.values())
        results[area] = {
            'status':'passed', 'facility_count':len(records),
            'schools':sum(f.record.service_type=='school' for f in attached.facilities),
            'hospitals':sum(f.record.service_type=='hospital' for f in attached.facilities),
            'retained_nodes':len(graph), 'retained_directed_arcs':graph.number_of_edges(),
            'cleaning':cleaning, 'attached_facilities':len(attached.facilities),
            'distinct_attachment_nodes':len({f.node_id for f in attached.facilities}),
            'maximum_facility_snap_m':maximum, 'facility_snap_limit_m':snap_limit,
            'attachments_over_500m':[f.public() for f in attached.facilities if f.snap_m>500],
            'demand_basis':'uniform_node_demand', 'time_model':times.summary,
            'baseline_2sfca_validation':baseline.summary,
            'checks':['Directory resolves exactly one road file', 'Full capacity-aware CSV validation',
                'Every capacity equals one assumed unit', 'Drive network cleaning without consolidation',
                'Every facility attaches within the declared snap limit', 'Static travel times available',
                'Baseline 2SFCA computed for both categories'],
            'facility_attachments':[f.public() for f in attached.facilities]}
        print(area, {k:results[area][k] for k in ('facility_count','schools','hospitals','retained_nodes',
            'maximum_facility_snap_m','facility_snap_limit_m')}, flush=True)
    target = BASE / 'validation.json'
    target.write_text(json.dumps({'software_versions':_versions(), 'areas':results},indent=2)+'\n')
    return results


if __name__ == '__main__':
    validate()
