"""Launch GeoResilience with portable paths and the validated scenario settings."""
import argparse
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

BASE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--area', choices=('both','gachibowli','old-hyderabad'), default='both')
    parser.add_argument('--out', type=Path, required=True, help='parent directory for per-area results')
    parser.add_argument('--coverage', choices=('screened','all'), default='screened')
    parser.add_argument('--catchment-minutes', type=float, default=10)
    parser.add_argument('--samples', type=int, default=64)
    parser.add_argument('--jobs', type=int, default=8)
    parser.add_argument('--overwrite', action='store_true')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    if args.catchment_minutes <= 0 or args.samples < 2 or args.jobs < 1:
        parser.error('catchment must be positive, samples at least 2 and jobs at least 1')
    validation = json.loads((BASE / 'validation.json').read_text())['areas']
    areas = ('gachibowli','old-hyderabad') if args.area == 'both' else (args.area,)
    env = dict(os.environ)
    env.setdefault('MPLCONFIGDIR', str(Path(os.getenv('TMPDIR','/tmp')) / 'georesilience-mpl'))
    env['OPENBLAS_NUM_THREADS'] = '1'
    env['OMP_NUM_THREADS'] = '1'
    for area in areas:
        inputs = BASE / 'inputs' / area
        cmd = [sys.executable, '-m', 'georesilience.cli', 'run', str(inputs),
            '--out', str(args.out.expanduser().resolve() / area),
            '--facilities', str(inputs / 'facilities.csv'), '--service-mode','2sfca',
            '--service-catchment-minutes',f'school={args.catchment_minutes}',
            '--service-catchment-minutes',f'hospital={args.catchment_minutes}',
            '--service-unit','school=assumed_school_capacity_units',
            '--service-unit','hospital=assumed_hospital_capacity_units',
            '--service-importance','school=1', '--service-importance','hospital=1',
            '--population-importance','1', '--no-consolidation',
            '--facility-snap-max-m',str(validation[area]['facility_snap_limit_m']),
            '--criticality-coverage',args.coverage,
            '--connectivity-samples',str(args.samples),'--travel-time-samples',str(args.samples),
            '--attack-order','static','--attack-fraction','0.01','--attack-steps','10',
            '--jobs',str(args.jobs),'--max-memory-gb','0.5','--seed','42']
        if args.overwrite:
            cmd.append('--overwrite')
        print(shlex.join(cmd),flush=True)
        if not args.dry_run:
            subprocess.run(cmd,env=env,check=True)


if __name__ == '__main__':
    main()
